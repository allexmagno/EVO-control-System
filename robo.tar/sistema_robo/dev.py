import threading
from coordenadas import *
from time import sleep

coord = Coordenadas(1,2,'n')

print (coord.toString())
c = "magno"

